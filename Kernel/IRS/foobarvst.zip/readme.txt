George Yohng's VST Wrapper for Foobar2000 player
Version 1.2

Copyright (C)2007-2009 by George Yohng

Version history:

Version 1.2
 - Fixed popup menu position on Vista
 - Removed default C:\Program Files\VSTPlugins directory from being added

Version 1.1
 - 'Rescan all' in VST settings now works properly
 - Local plugins folder at ....\foobar2000\VST

Version 1.0
 - Initial release

INSTALLATION:

To enable this plugin, copy foo_dsp_vstwrap.dll to foobar2000 components
directory, which is typically 
C:\Program Files\foobar2000\components

then enable the plugin in a DSP manager. Ctrl-P to bring Properties window 
up, then select Playback->DSP Manager and be sure that "George Yohng's 
VST Wrapper" is in the 'Active DSPs' column.

USAGE:

The plugin control is done through a system tray icon. Please set up
your VST folders before proceeding by selecting "VST Setup..." from
the tray icon menu. "Steinberg Mode" is an experimental mode, which
will allow running some of Cubase internal plugins, which otherwise
would complain, but some plugins will crash in this mode. "Bypass" 
turns the effect temporarily off without unloading it.

Additionally, Ctrl-click on the tray icon will toggle visibility of
a plugin editor (if a plugin is inserted), and Alt-click on the 
tray icon will toggle the bypass mode.

If foobar2000 installation directory contains "VST" subdirectory, then
it will be also enumerated, regardless of VST Setup settings. E.g.,
if "C:\Program Files\foobar2000" is where foobar is installed, then
the folder "C:\Program Files\foobar2000\VST" will be also scanned for
VST plugins. This is useful for 'portable installations', where foobar
is executed from an USB stick or a network drive.


TROUBLESHOOTING:

If a plugin crashes on start of Foobar2000, press shift while executing
Foobar2000. This will disable loading of the last plugin on startup.

All settings of VST Wrapper are stored in the file, which is typically
located at:
C:\Documents and Settings\All Users\Application Data\GeorgeYohngVST.ini

Deleting this file will reset VST cache and all options to default values.

ADDITIONAL:

This archive includes George Yohng's W1 Limiter, a free sample VST plugin.
To use it, copy it to a directory, which is included in "VST Setup..."
dialog. More information about W1 Limiter is available on this page:
http://www.yohng.com/w1limit.html

TERMS AND CONDITIONS:

Redistribution and use is permitted without limitations, as long as
the package is unmodified.

DISCLAIMER:

THIS SOFTWARE IS PROVIDED BY GEORGE YOHNG "AS IS" AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL GEORGE YOHNG BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

